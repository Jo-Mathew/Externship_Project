import numpy as np
import os
from tensorflow.keras.models import load_model
from tensorflow.keras.preprocessing import image
import tensorflow as tf

from flask import Flask , request, render_template
#from werkzeug.utils import secure_filename
#from gevent.pywsgi import WSGIServer



app = Flask(__name__)
model = load_model("eye_cnn .h5")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/inner-page')
def inner_page():
    return render_template('inner-page.html')


@app.route('/predict',methods = ['GET','POST'])
def upload():
    if request.method == 'POST':
        f = request.files['image']
        
        #print("current path")
        basepath = os.path.dirname(__file__)
        print("current path", basepath)
        filepath = os.path.join(basepath,'uploads',f.filename)
        print("upload folder is ", filepath)
        f.save(filepath)
        
        img = image.load_img(filepath,target_size = (64,64))
        x = image.img_to_array(img)
        x = np.expand_dims(x,axis =0)
        preds = model.predict(x)
        
        print("prediction",preds)
         
        print(np.argmax(preds))
        if np.argmax(preds) == 0:
            prediction_result = "You have cataract type of eye disease."
        elif np.argmax(preds) == 1: 
            prediction_result = "You have diabetic retinopathy type of eye disease."
        elif np.argmax(preds) == 2:
            prediction_result = "You have glaucoma type of eye disease."
        elif np.argmax(preds) == 3:
            prediction_result = "You have normal eye."
        else:
            prediction_result == 'unknown'
    
        text= prediction_result
    return text
if __name__ == '__main__':
    app.run(debug = False, threaded = False)
        
        
   
    
    
    